//
//  ViewController.swift
//  ImageDictionary
//
//  Created by 14 김세현 on 31/05/2019.
//  Copyright © 2019 comp420. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

